#include "ProductInfo.h"

ProductInfo::ProductInfo(int id_product, int expires_in, int shelve_id, int product_price)
    : id_product(id_product), expires_in(expires_in), shelve_id(shelve_id), product_price(product_price) {}
