#include "ProductInfo.h"

ProductInfo::ProductInfo(int shelveId)
    : shelveId(shelveId) {}
